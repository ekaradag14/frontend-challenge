

//Define a prototype method to get a random element from array
Array.prototype.random = function () {
	return this[Math.floor(Math.random() * this.length)];
};
//Global Variables

const emptyString = 'empty';

class PuzzleModule {

	firstCheck = (matrixVolume) => {
		if (matrixVolume > 8) {
			for (var i = 0; i < matrixVolume - 9; i++) {
				var ul = document.getElementsByClassName('puzzle')[0];
				var li = document.createElement('li');
				li.appendChild(document.createTextNode((8 + i).toString()));
				ul.appendChild(li);
			}
		}
	};

	addCSSClass = (innerHTML) => {
		var style = document.createElement('style');
		style.type = 'text/css';
		style.innerHTML = innerHTML;
		document.getElementsByTagName('head')[0].appendChild(style);
	};
	defineCSSClasses = (puzzleState,matrixVolume) => {
		//Define Classes for every position
		matrixVolume.forEach((row, rowNo) => {
			row.forEach((el, columnNo) => {
				//Classes also represents coordinates which is why they are created in x(Number)y(Number) format
				this.addCSSClass(`
			.x${rowNo}y${columnNo} {
				position: absolute;
				top: ${0.5 + 6 * rowNo}vw;
				left: ${0.5 + 6 * columnNo}vw; 
			}`);
			});
		});
		//Define ul class
		this.addCSSClass(`
	ul	{
	padding: 0px;
	background: black;
	width: ${puzzleState[0].length * 5 + puzzleState[0].length}vw;
	justify-content: space-evenly;
	border: 0.5vw solid black;
	display: flex;
	flex-wrap: wrap;
	border-radius: 0.5vw;
	list-style-type: none;
	list-style: none;
	height: ${puzzleState.length * 5 + puzzleState.length}vw;
	}`);
		//Define li class
		this.addCSSClass(`
	li	{
	width: 5vw;
	height: 5vw;
	border: 0.5vw inset gray;
	background: white;
	display: flex;
	justify-content: center;
	align-items: center;
	font-size: 1.5em;
	}`);
	};
	shufflePuzzle = (matrixVolume,rowVolume) => {
		const numbers = [];
		//Find used numbers from the puzzleState
		for (var i = 1; i < matrixVolume + 1; i++) {
			numbers.push(i);
		}

		let initialPuzzleState = [];
		let shuffledPuzzleState = [];

		//Randomly generate the initial Puzzle
		for (var i = 1; i < matrixVolume; i++) {
			let randomElement = numbers.random();
			numbers.splice(numbers.indexOf(randomElement), 1);
			initialPuzzleState.push(randomElement);
		}

		//Randomly select a point to insert empty tile
		let cutPoint = Math.floor(Math.random() * (matrixVolume - 1)) + 1;
		initialPuzzleState = [
			...initialPuzzleState.slice(0, cutPoint),
			emptyString,
			...initialPuzzleState.slice(cutPoint, initialPuzzleState.length),
		];
		//Format the array into a matrix
		for (var i = 0; i < rowVolume; i++) {
			shuffledPuzzleState[i] = initialPuzzleState.slice(
				i * rowVolume,
				(i + 1) * rowVolume
			);
		}
		//Update the app state with the shuffled puzzle
		return shuffledPuzzleState;
	};

	renderPuzzle = (currentPuzzleState,rowVolume) => {
		let liElements = document.getElementsByTagName('li');
		//Create a checkpoint to control is the empty element passed. So we do not have any array boundary problems
		let isPassedEmpty = false;
		currentPuzzleState.forEach((row, rowNo) => {
			row.forEach((element, columnNo) => {
				if (element === emptyString) {
					isPassedEmpty = true;
				} else {
					//Create a class to serve as coordinates and styling
					liElements[
						isPassedEmpty
							? rowNo * rowVolume + columnNo - 1
							: rowNo * rowVolume + columnNo
					].setAttribute('class', `x${rowNo}y${columnNo}`);
					//Add onclick event to pass class whenever clicked
					liElements[
						isPassedEmpty
							? rowNo * rowVolume + columnNo - 1
							: rowNo * rowVolume + columnNo
					].onclick = (e) => {e.preventDefault(); this.elementClicked(`x${rowNo}y${columnNo}`});

					document.getElementsByClassName(
						`x${rowNo}y${columnNo}`
					)[0].innerHTML = element;
				}
			});
		});
	};
	elementClicked = (classNameString) => {
		//Get the coordinates of the element from its class
		let xPosition = Number(classNameString.charAt(1));
		let yPosition = Number(classNameString.charAt(3));
		let emptyPosition;

		//Find the empty element's coordinates
		settings.puzzleState.forEach((row, rowNo) => {
			row.forEach((element, columnNo) => {
				if (element === emptyString) {
					emptyPosition = [rowNo, columnNo];
					console.log(emptyPosition, emptyString);
				}
			});
		});

		//Check if the clicked element is moveable by comparing their distance
		let isMoveable =
			Math.abs(emptyPosition[0] - xPosition) +
				Math.abs(emptyPosition[1] - yPosition) <
			2;
		//If element is moveable update the state
		if (isMoveable) {
			settings.puzzleState[emptyPosition[0]][emptyPosition[1]] =
				settings.puzzleState[xPosition][yPosition];
			settings.puzzleState[xPosition][yPosition] = emptyString;

			this.renderPuzzle(settings.puzzleState);
		}
	};
}

//App State
let newPuzzle = new PuzzleModule();
//Helper functions
//#region

//#endregion

//Render the initial state on window.load
window.onload = function () {
	newPuzzle.firstCheck();
	newPuzzle.renderPuzzle(newPuzzle.shufflePuzzle());
	newPuzzle.defineCSSClasses();
};

sayHello = () => {
	newPuzzle.renderPuzzle(newPuzzle.shufflePuzzle());
};

