//#region
export const addCSSClass = (innerHTML) => {
	var style = document.createElement('style');
	style.type = 'text/css';
	style.innerHTML = innerHTML;
	document.getElementsByTagName('head')[0].appendChild(style);
};
export const defineCSSClasses = () => {
	//Define Classes for every position
	puzzleState.forEach((row, rowNo) => {
		row.forEach((el, columnNo) => {
			//Classes also represents coordinates which is why they are created in x(Number)y(Number) format
			addCSSClass(`
			.x${rowNo}y${columnNo} {
				position: absolute;
				top: ${0.5 + 6 * rowNo}vw;
				left: ${0.5 + 6 * columnNo}vw; 
			}`);
		});
	});
	//Define ul class
	addCSSClass(`
	ul	{
	padding: 0px;
	background: black;
	width: ${puzzleState[0].length * 5 + puzzleState[0].length}vw;
	justify-content: space-evenly;
	border: 0.5vw solid black;
	display: flex;
	flex-wrap: wrap;
	border-radius: 0.5vw;
	list-style-type: none;
	list-style: none;
	height: ${puzzleState.length * 5 + puzzleState.length}vw;
	}`);
	//Define li class
	addCSSClass(`
	li	{
	width: 5vw;
	height: 5vw;
	border: 0.5vw inset gray;
	background: white;
	display: flex;
	justify-content: center;
	align-items: center;
	font-size: 1.5em;
	}`);
};
export const shufflePuzzle = () => {
	//Find used numbers from the puzzleState
	let numbers = puzzleState.flat();
	numbers.splice(numbers.indexOf('empty'), 1);
	numbers = numbers.sort((a, b) => a - b);

	let initialPuzzleState = [];
	let shuffledPuzzleState = [];

	//Randomly generate the initial Puzzle
	for (var i = 1; i < matrixVolume; i++) {
		let randomElement = numbers.random();
		numbers.splice(numbers.indexOf(randomElement), 1);
		initialPuzzleState.push(randomElement);
	}

	//Randomly select a point to insert empty tile
	let cutPoint = Math.floor(Math.random() * (matrixVolume - 1)) + 1;
	initialPuzzleState = [
		...initialPuzzleState.slice(0, cutPoint),
		emptyString,
		...initialPuzzleState.slice(cutPoint, initialPuzzleState.length),
	];
	//Format the array into a matrix
	for (var i = 0; i < rowVolume; i++) {
		shuffledPuzzleState[i] = initialPuzzleState.slice(
			i * rowVolume,
			(i + 1) * rowVolume
		);
	}
	//Update the app state with the shuffled puzzle
	return shuffledPuzzleState;
};

export const renderPuzzle = (currentPuzzleState) => {
	let liElements = document.getElementsByTagName('li');
	//Create a checkpoint to control is the empty element passed. So we do not have any array boundary problems
	let isPassedEmpty = false;
	currentPuzzleState.forEach((row, rowNo) => {
		row.forEach((element, columnNo) => {
			if (element === emptyString) {
				isPassedEmpty = true;
			} else {
				//Create a class to serve as coordinates and styling
				liElements[
					isPassedEmpty
						? rowNo * rowVolume + columnNo - 1
						: rowNo * rowVolume + columnNo
				].setAttribute('class', `x${rowNo}y${columnNo}`);
				//Add onclick event to pass class whenever clicked
				liElements[
					isPassedEmpty
						? rowNo * rowVolume + columnNo - 1
						: rowNo * rowVolume + columnNo
				].setAttribute('onClick', `elementClicked('x${rowNo}y${columnNo}')`);
				document.getElementsByClassName(`x${rowNo}y${columnNo}`)[0].innerHTML =
					element;
			}
		});
	});
};
//#endregion
